# Task-specific skill contract

Use this checklist while producing the skill, not as a questionnaire to dump on the user. Omit irrelevant fields; resolve important gaps in conversation.

## Minimum executable contract

| Element | Capture |
| --- | --- |
| Goal | Beneficiary, desired result, and reason it matters |
| Trigger | User requests or situations that should invoke the skill |
| Scope | Included work and meaningful exclusions |
| Inputs | Required evidence, optional context, source access |
| Process | Actions, dependencies, and decision branches |
| Expert judgment | Cues, rules, tradeoffs, rejection criteria |
| Missing evidence | When to ask, retrieve, proceed with unknowns, or stop |
| Output | Structure, audience, and definition of done |
| Human role | Decisions and external actions requiring human involvement |
| Validation | Representative case, variation, acceptance criteria |

## Evaluate with observable criteria

Use a small rubric suited to the task:

- Does the result address the underlying need?
- Are material factual claims supported by supplied or retrieved evidence?
- Are consequential unknowns visible and handled correctly?
- Does the workflow apply to a new case without sample-specific assumptions?
- Are tool requirements executable in the actual environment?
- Does the output meet the user's acceptance criteria?
- Is reduced effort or improved quality measured, estimated, or still untested?

Record findings and revise the instructions rather than teaching the evaluator the expected answer. Do not embed transient test logs or invented business facts in the installed skill.
