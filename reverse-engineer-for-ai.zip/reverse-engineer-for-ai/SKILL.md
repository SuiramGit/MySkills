---
name: reverse-engineer-for-ai
description: Reverse engineer human problems, tasks, and processes into more effective AI workflows and reusable skills. Use when a user wants to unpack how work is done, surface tacit judgment, rethink a manual process for AI, or turn an outcome into an executable skill. Interview conversationally, redesign around the outcome, build the resulting skill, and validate it against realistic examples. Apply across domains; do not specialize this general method around the first example.
---

# Reverse Engineer for AI

## Lead a conversation toward a working skill

Use the user's language and level of technical detail. Treat this skill as a general method for producing task-specific skills. Keep its method separate from the particular skill being produced. Never redefine the general method around a user's example.

Start by asking what problem the user wants to solve and what a successful result looks like, unless already answered. Ask one focused question per turn by default; combine two only when tightly related. Explain a question's purpose when it is not obvious. Avoid questionnaires, repeated confirmation, and requests for information already supplied or available in authorized sources.

Maintain a short working brief as the conversation develops: desired outcome, current process, evidence, constraints, open questions, and success criteria. Label assumptions. Use examples as evidence rather than as the full scope. Move to building when remaining uncertainties can be handled explicitly in the generated skill; do not interview indefinitely.

## 1. Recover the actual problem

Identify the beneficiary, triggering situation, desired output or decision, and what makes it useful. Separate the underlying goal from the user's proposed mechanism. For example, distinguish 'produce a report' from the decision the report enables.

Ask for one concrete recent or representative case. Recover the starting information, actual result, and what was difficult. Accept messy notes or a verbal account. Request sensitive details only when needed and support anonymized examples.

Define observable success: quality, elapsed time, human effort, consistency, cost, or another relevant measure. Do not invent a baseline or claim savings without measurement. Where no baseline exists, agree on an acceptance rubric and describe efficiency estimates as hypotheses.

## 2. Unpack how humans currently achieve it

Recover only the detail needed to redesign the work:

- Inputs, sources, access, freshness, and common gaps.
- Actions, handoffs, waiting, duplication, and system boundaries.
- Decisions, rules, exceptions, and escalation points.
- Tacit expertise: cues an expert notices, acceptable tradeoffs, and how they recognize a bad result.
- Output users, required structure, quality checks, and consequences of error.

Use contrast questions selectively: 'What would make you reject this result?' or 'When would you handle it differently?' Ask for a counterexample if the happy path conceals important judgment. Separate observed facts, user statements, and your inferences.

When material is incomplete, distinguish nonessential gaps from facts that control correctness. Proceed with explicit unknowns when possible; ask about consequential gaps. Never fill missing commitments, capabilities, prices, responsibilities, or other material facts with plausible inventions.

## 3. Redesign around the outcome

Treat the current process as evidence, not a specification to reproduce. Consider removing unnecessary work, simplifying decisions, combining steps, retrieving existing evidence, restructuring inputs, and adding tools only where useful.

Assign each retained activity to an appropriate execution method: deterministic rule or script, information retrieval, AI synthesis or reasoning, human judgment, or a combination. Keep consequential judgment with a human when available evidence and validation cannot support reliable delegation. Do not force AI into tasks better solved by a simpler change.

Prefer the smallest sufficient solution. A single skill is the default; propose orchestration or multiple skills only when distinct responsibilities or reuse justify them. Do not assume integrations exist. Discover relevant tools when needed and state required access honestly.

Briefly explain the proposed workflow, expected benefit, and material tradeoff before building. Ask a follow-up only if an unresolved choice materially changes the solution. Treat the user's request to create the solution as authorization for reversible implementation; follow applicable rules for external actions.

## 4. Compile the solution into a reusable skill

Use the applicable skill-creator instructions for initialization, metadata, validation, and persistence. If that capability is unavailable, produce complete skill source and clearly describe the installation limitation. Do not claim installation from text alone.

Read `references/skill-contract.md` for the minimum contract and acceptance approach. Write concrete instructions for execution, not a generic essay about AI. Capture the recovered expert judgment and decision rules. Keep instructions domain-specific in the new skill while leaving this general method reusable.

Specify:

- Trigger and boundaries, including cases outside scope.
- Minimum inputs and where to obtain them.
- Ordered execution steps and branches for incomplete or conflicting evidence.
- Rules for inference, traceability, uncertainty, and human decisions.
- Output structure, completion criteria, and recovery from common failures.
- Tools and permissions only where actually required.

Make the generated skill usable with new cases. Never hardcode a sample's identities or values as universal rules. Add references or scripts only when they improve repeated execution. Test any added scripts by running them.

Build the artifact once enough context exists. Do not stop at recommendations, a prompt outline, or a promise to build later.

## 5. Test whether the redesign works

Use the representative case and at least one variation involving missing information, an exception, or a different context. Prefer an independent forward test when available, following the applicable skill-creator guidance. Give the evaluator the skill and task-local evidence without the intended answer or your diagnosis. Keep tests local or simulated unless external execution is authorized.

Check output usefulness, factual support, handling of uncertainty, required human effort, and compliance with the recovered decision rules. Inspect actual outputs; structural validation alone does not establish that the workflow works. Revise failures and rerun affected checks.

When testing lacks real inputs, use explicitly synthetic cases to test behavior and describe validation as provisional. Do not claim demonstrated efficiency gains from a synthetic example. Compare against the baseline only when measured; otherwise state what remains to be tested.

Deliver the saved skill's name, how to invoke it, its practical purpose, and the material validation limit. Follow the environment's persistence rules. Distinguish source created, validated, saved, and available rather than claiming all four without evidence.
