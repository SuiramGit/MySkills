# Aktiver

Alle leverede filer er kopieret uændret til `assets/brandpakke/` i skill-mappen. Se `asset-manifest.json` for filnavne, dimensioner, farvemodus og SHA-256. Åbn valgte billeder før brug; navne er ikke tilstrækkelig visuel dokumentation.

| Behov | Mappe/fil under assets/brandpakke |
|---|---|
| Standard digitalt logo | `1 Logo/Digitalt & web/Logo-Netic-Plain-RGB-Brand-blue.png` |
| Lys version på mørk flade | `1 Logo/Digitalt & web/Logo-Netic-Plain-RGB-White.png` |
| Logo med tagline | `1 Logo/Digitalt & web/Logo-Netic-Tagline-RGB-Brand-blue.png` samt de leverede lyse varianter |
| Favicon/profilikon | `1 Logo/Digitalt & web/Logo-Netic-Ikon-RGB-Brand-blue.png` eller `Logo-Netic-Ikon-RGB-White.png` |
| Tryklogoer | `1 Logo/Tryk/SVG/` og `1 Logo/Tryk/PNG/` |
| Datacenter- og medarbejderfotos | `3 Billedbank/` |
| Contain-ikon | `4 Ikoner/Contain_ikon.svg` og `Contain-ikon.png` |
| Dekorativ n-kontur | `5 Grafik/Netic_graphic-outline.svg` |
| Bølgelinjer | `5 Grafik/Radiant Flow Lines-05_mainblue_3840.png` |
| Illustrationer | `5 Grafik/Illustrationer/` |
| Eksempel på teknisk model | `5 Grafik/Tekniske modeller/Contain-model.png` |
| Færdige LinkedIn-bannere | `5 Grafik/LinkedIn Banner/` |
| Mødebaggrunde | `5 Grafik/Teams og Google meet baggrunde/` |

## Formatfælder

- Digitalt plain-logo er 1000 × 468 px inklusive transparent margen. Skaler proportionelt og beregn afstand efter det synlige logo.
- RGB-blue-logoets massive pixels er #40687F. White-varianten er faktisk #FFFFFF, ikke palettens Off White. Bevar de officielle logofiler; genfarv ikke automatisk for at normalisere dem.
- Tryk-SVG'en `Logo-Netic-Plain-CMYK-Brand-blue.svg` indeholder #2F789C. Det er ikke den digitale brandfarve. Et filnavn med CMYK beviser heller ikke, at en PNG/SVG er en farvestyret CMYK-leverance. Afklar outputprofil ved trykproduktion.
- Der er flere næsten ens tagline-/white-filer og medarbejderfilnavne. Vælg efter visuel kontrol frem for at antage at de er dubletter.
- Der følger ingen fontfiler, redigerbar PPTX/DOCX-master eller komplet generelt ikonbibliotek med. Links er ikke det samme som lokale skabeloner.
