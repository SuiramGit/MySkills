# Netics brandregler

Kilde: Netic Brandguide v1.23, 18.09.2026, visuelt gennemgået 25.09.2026. Sidetal nedenfor er guidens trykte sidetal.

## Logo (s. 7–9)

- Primært logo: plain uden tagline. Tagline-version har teksten “A TRIFORK COMPANY” og anvendes kun når den er læsbar. Brug den originale fil, ikke nysat tekst.
- Fri afstand omkring ordlogo svarer til størrelsen på logoets n; omkring ikonet svarer den til et halvt n. Mål efter det synlige mærke, ikke blot billedfilens yderkant: PNG-filer har transparent margen.
- Vælg blå eller lys originalvariant mod en baggrund med tydelig kontrast. Logo og baggrund skal følge paletten.
- Bevar proportioner og bogstavplacering. Ingen beskæring, deformation, outline eller ændring af tagline-font. Guiden tillader 90° rotation af ordlogo; vilkårlig rotation er forkert. Det dekorative n-element må derimod ikke roteres.
- Partneropsætninger kan være vandrette eller lodrette med mellemrum, & eller skillelinje som vist på s. 8. Ved konkret co-branding kontrolleres originalens afstandsdiagram; opfind ikke præcise forhold ud fra miniatureeksemplet.

## Typografi (s. 10–11)

Barlow: Light, Regular, Medium, Semibold samt Light Italic. Arial til kontrakter og dokumenter, der skal redigeres af kunder.

Webeksempel, ikke universelle størrelser:

| Rolle | Størrelse/vægt | Bogstavafstand | Linjehøjde |
|---|---|---|---|
| H1 | 80 px Regular | −4 % | 100 % |
| Underoverskrift | 24 px Light | 0 | 120 % |
| Pretitel | 16 px Bold | +2 % | 120 % |
| H2 | 40 px Regular | −2 % | 105 % |
| Brødtekst | 16 px Light | 0 | 130 % |

Eksemplet viser 16 px mellem pretitel, H2 og brødtekst og 48 px mellem større elementer. Tilpas størrelser og linjehøjde til det konkrete medie og læsbarhed.

## Primær palette (s. 12–13)

| Navn | HEX aflæst i guiden | Rolle | Vejledende fordeling |
|---|---|---|---|
| Main Blue | #40687F | Primær brandfarve og logo | 20 % |
| Light Blue | #E4EEF4 | Lys flade | 25 % |
| Off White | #FAF8F7 | Baggrund og lys tekst | 25 % |
| Light Red | #E8DEDE | Lys sekundær flade | 15 % |
| Bold Red | #8D3B44 | Fremhævning og CTA | 10 % |
| Off Black | #384E5B | Kun tekst | 5 % |

Fordelingen gælder det samlede visuelle indtryk, ikke matematisk tvang på hver side. Bold Reds RGB-linje blev aflæst som 140,59,68, mens HEX-linjen blev aflæst som #8D3B44; disse er ikke identiske. Brug ovenstående HEX som arbejdsvalg og genkontrollér originalt farvetoken før farvekritisk aflevering. Main Blue er også bekræftet i det lokale RGB-logo (64,104,127).

Guiden viser følgende tekst/baggrundspar: Off Black, Main Blue eller Bold Red på Off White, Light Blue eller Light Red; Off White, Light Blue eller Light Red på Main Blue eller Bold Red. Kontrollér kontrast i den faktiske anvendelse, især små/tynde tekster. Guidens AA/AAA-markeringer er ikke en blanketgodkendelse af enhver tekststørrelse og komponent.

S. 14 har en udvidet palette til digitale UI, komplekse modeller og grafer, når primærpaletten ikke rækker. Den erstatter aldrig primærfarverne. De små sekundære HEX-værdier er ikke transskriberet; slå relevante tokens op i originalen før brug. Opfind ikke officielle statusfarver.

## Grafik og layout (s. 15–17)

- Placér dekorative linjer, bølger og n-kontur i områder med luft; de må gerne gå ud over kanten. De må ikke ligge under/over tekst, logo eller CTA.
- Brug brandfarver og godkendte kombinationer. Rotér ikke n-konturen og beskær den ikke så den ligner et o.
- Runde hjørner: normalt 24 px for store kasser, sektioner og primære containere; 12 px for mindre elementer, billeder og indlejrede kasser. Oversæt proportionelt til andre medier.
- Knapper er runde med Medium-tekst; outline-knapper har 1,5 px streg. Relevante ikoner kan indgå.
- Praktisk layoutfortolkning af guidens eksempler: lyse rolige flader, tydeligt venstrestillet hierarki, luft og afgrænsede billed-/tekstfelter. Dette er en anvendelse af eksemplerne, ikke et dokumenteret universelt grid eller krav om fast antal kolonner.

## Fotos, illustrationer og ikoner (s. 18–21)

- Prioritér personlige, ægte, realistiske og troværdige fotos. Stock kan bruges ved behov; overgjorte stockfotos og AI-genererede billeder fravælges.
- Illustrationer supplerer fotos til koncepter, services og pointer som fotografier ikke kan vise. Genbrug den eksisterende illustrationsstil.
- Ikoner har tynde streger, rundinger og runde hjørner. Udgangspunktet er Lucide ved behov ud over biblioteket; match eksisterende ikoner.
- Størrelse/stregtykkelse: 256/4 px, 128/3 px, 64/2,5 px, 32/2 px, 24/1,5 px.
- Tekniske komponenter i Google Slides bruges til systemer/modeller. Den lokale Contain-model er et eksempelbillede, ikke dokumentation for brugerens konkrete arkitektur.

## Tone og budskaber (s. 3–6)

Kommunikér fagligt, personligt og i øjenhøjde med ro, omhu og autoritet. Brug et klassisk, velovervejet udtryk og positive løsningsforslag. Britisk engelsk ved engelsksproget materiale.

Primære værdier: ordentlighed, tillid, specialisering og ansvarlighed. Guidens kernebudskaber omfatter suverænitet, ansvarlighed, gennemsigtighed, specialisering og nærhed. Brug kun budskaber, som passer til opgaven og kan underbygges.

Undgå frygtbaseret clickbait, arrogance, flabet sprog og unuancerede enten/eller-påstande. Virksomhedsbeskrivelse og eksempeltekster er ikke bevis for aktuelle certificeringer, produktfunktioner eller løfter til en kunde.
