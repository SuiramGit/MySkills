# Kildestatus og vedligeholdelse

Dato: 25.09.2026. Formål: genbrugelig skill til Netics brand, design og layout på tværs af opgaver. Placering: `/Users/sik/.codex/skills/netic-brand-design`. Ingen særskilt projektmappe er oprettet; ISO-14001-projektet er ikke ændret.

## Faktisk udført

- Brandguidens 22 sider gennemgået visuelt via Figma-prototypen. Version 1.23, senest opdateret 18.09.2026, fremgår på s. 22.
- Brandregler sammenfattet med sidereferencer; originale lokale aktiver kopieret uændret og registreret med SHA-256.
- Kildepakken: `/Users/sik/Downloads/drive-download-20260925T091825Z-1-001/`. Pakken er modtaget fra brugeren; downloadnavnets dato er ikke nødvendigvis hver fils produktionsdato.
- Lokal kopi er et snapshot. Figma-guiden er den eksterne reference. Guiden er mærket “Internal use only”; skillen giver ikke i sig selv tilladelse til at offentliggøre guiden eller hele aktivpakken.

## Begrænsninger og næste skridt ved behov

- Barlow-fontfiler er ikke inkluderet eller installeret af denne opgave.
- Google Slides-link er et generelt galleri. En konkret Netic-master er ikke åbnet/verificeret.
- Udvidet palettes små HEX-værdier og partnerlogoets præcise diagrammål er ikke transskriberet. Genkontrollér originalen ved relevante opgaver.
- Bold Reds HEX/RGB-aflæsning har en mulig uoverensstemmelse, dokumenteret i brandreglerne. Genkontrollér ved farvekritisk brug.
- Ingen genereret slutleverance i PPTX/DOCX er testet. Skillens struktur er valideret med quick_validate.py; alle 63 kopier er kontrolleret mod originalernes SHA-256, og lokale Markdown-referencer er kontrolleret; aktivering i en ny app-session er ikke afprøvet her.
- Ved opdatering bevares kilde/version og forskel på officielle krav, aflæsninger og egne layoutvalg. Opdatér denne status og manifest ved ændringer.

## Kildelinks

- 2 Skabeloner/Google Slides.webloc: https://docs.google.com/presentation/u/0/?tgif=d&ftv=1
- 4 Ikoner/0 Ikon bibliotek.webloc: https://www.figma.com/design/8XPICoac5YVbzmSxKdOOnZ/Brandguide?node-id=304-144&p=f&t=l1JBMtgLyARRXMaq-0
- 5 Grafik/Grafik i Figma.webloc: https://www.figma.com/design/8XPICoac5YVbzmSxKdOOnZ/Brandguide?node-id=331-71&p=f&t=l1JBMtgLyARRXMaq-0
- 0 Brandguide/Brandguide - Online brandguidelines.webloc: https://www.figma.com/proto/8XPICoac5YVbzmSxKdOOnZ/Brandguide?page-id=0%3A1&node-id=1-2&viewport=-150%2C421%2C0.21&t=fcOXHzBuN3kKHQkr-1&scaling=contain&content-scaling=fixed&starting-point-node-id=1%3A2
