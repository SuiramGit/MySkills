---
name: netic-slide-consulting
description: "Forbedr og omstruktur\xE9r eksisterende PowerPoint-pr\xE6sentationer\
  \ efter Netics brandguide og McKinsey-inspirerede konsulentprincipper. Brug ved\
  \ slide reviews, storylining, omskrivning, prioritering, visualisering og produktion\
  \ af redigerede Netic-decks."
---

# Netic-præsentationer i konsulentstil

Forbedr brugerens eksisterende præsentation uden at ændre dokumenterede fakta. Kombinér Netics visuelle identitet med en hypotesedrevet, top-down konsulentfortælling. Brug altid den uploadede præsentation som udgangspunkt og `assets/netic-template.pptx` som konkret visuel reference.

## Arbejdsgang

1. Fastlæg præsentationens modtager, beslutning og formål ud fra brugerens besked og decket. Spørg kun, hvis et manglende svar vil ændre den centrale storyline.
2. Gennemgå hele decket før redigering. Identificér hovedbudskab, logiske huller, gentagelser, svage beviser, overfyldte slides og inkonsistent design.
3. Formulér en top-down storyline: situation, komplikation, nøglespørgsmål, svar/anbefaling og underbyggende argumenter. Brug MECE som kvalitetstest, ikke som mekanisk skabelon.
4. Skriv handlingsorienterede slide-titler, der udtrykker konklusionen. Hver slide skal have ét primært budskab, og titlerne skal kunne læses som et sammenhængende executive summary.
5. Vælg den enkleste evidensform, der beviser pointen: kort tekst, tabel, proces, matrix, tidslinje eller diagram. Fjern dekoration og data, som ikke støtter budskabet.
6. Bevar og genbrug relevante layouts, mastere, farver, typografi og grafiske elementer fra `assets/netic-template.pptx`. Læs [brandregler](references/brandregler.md), og brug [aktivoversigten](references/aktiver.md) som katalog over kendte brandaktiver.
7. Skeln tydeligt mellem dokumenterede fakta, beregninger, antagelser og forslag. Opfind aldrig tal, kilder, kundecases eller konklusioner. Markér manglende evidens med en kort, konkret placeholder.
8. Kontrollér den renderede præsentation: rækkefølge, storyline, titel-logik, alignment, kontrast, faktisk font, tekstoverløb, billedbeskæring, læsbarhed og konsistens.
9. Lever det redigerede PowerPoint-deck samt en kort ændringslog med de vigtigste strukturelle valg, åbne antagelser og eventuelle manglende kilder.

## Agentic flywheel-metodik

Brug metodikken, når decket handler om agentiske processer, kontinuerlig forbedring, driftsmodeller, automatisering eller lærende systemer. Brug den som en strategisk fortolkningsramme, ikke som en obligatorisk skabelon for alle præsentationer.

Kernepåstanden er: Hver procesiteration skal efterlade systemet bedre end den foregående. Strukturér flywheel'et i fire trin:

1. **Transact** — Processen kører, og hver iteration eller transaktion registreres af agenterne. Vis tydeligt, hvilke hændelser, beslutninger, input og resultater der fanges.
2. **Observe** — Agenterne analyserer forløbet og identificerer mønstre, undtagelser, flaskehalse og ledig kapacitet. Skeln mellem observerede data og fortolkninger.
3. **Improve** — Agenterne omsætter læringen til konkrete forbedringer af procestrin, regler, prompts, beslutningslogik eller arbejdsdeling. Beskriv forbedringen og den forventede effekt.
4. **Deploy** — Den forbedrede proces sættes hurtigt i drift og starter næste, bedre iteration. Fremhæv korte læringssløjfer frem for lange releasecyklusser, men påstå ikke en bestemt implementeringstid uden evidens.

Når metodikken bruges i en præsentation:

- Gør den cirkulære feedbackmekanisme tydelig; Deploy skal føre tilbage til en ny Transact-iteration.
- Knyt hvert trin til konkrete aktører, data, beslutninger, kontrolpunkter og målbare resultater i brugerens case.
- Vis både den operationelle sløjfe og den akkumulerede forbedring over tid, når det styrker pointen.
- Brug handlingsorienterede titler, der forklarer forretningsværdien, fx at hver gennemført proces skaber ny læring og løfter næste iteration.
- Undgå at fremstille automatisk selvforbedring som ukontrolleret. Indbyg menneskelig godkendelse, governance, test og rollback, hvor risikoen eller konteksten kræver det.
- Markér som antagelse, hvis decket ikke dokumenterer, hvad der observeres, hvordan forbedringer valideres, eller hvordan de sættes i drift.
- Tilpas ordvalget til modtageren. Bevar de engelske trinbetegnelser, når de fungerer som modelnavne, og forklar dem kort på dansk i danske decks.

## Kvalitetsstandard

- Prioritér klarhed, præcision og beslutningsrelevans over pynt.
- Brug pyramideprincippet: svar først, derefter argumenter og evidens.
- Hold argumentgrupper gensidigt adskilte og samlet dækkende, når emnet tillader det.
- Brug konsekvent parallel formulering i lister og slide-sektioner.
- Bevar brugerens dokumenterede substans, men omskriv for skarphed og korthed.
- Plain-logo er standard. Barlow er brandfont; hvis den ikke er tilgængelig, brug en sikker erstatning og oplys afvigelsen.
- Genbrug ægte fotos og eksisterende grafiske aktiver. Generér ikke nye brandfotos som standard.
- Brug Slideworks-artiklen `https://slideworks.io/resources/how-mckinsey-consultants-make-presentations` som metodeinspiration, men påstå ikke officiel tilknytning til eller godkendelse fra McKinsey.

## Støttefiler

- [Brandregler](references/brandregler.md): farver, typografi, logo, layout og tone.
- [Aktivoversigt](references/aktiver.md): kendte logoer, billeder og grafiske elementer.
- [Kildestatus](references/kildestatus.md): versioner, begrænsninger og kildehenvisninger.
- [Aktivmanifest](references/asset-manifest.json): filmetadata for den oprindelige brandpakke.
- `assets/netic-template.pptx`: konkret reference for masters, layouts og præsentationsudtryk.
