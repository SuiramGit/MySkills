---
name: research-companies
description: Perform deep, source-backed online research into companies and their products, and compare vendors for business decisions. Use for company analyses, competitive intelligence, procurement and supplier selection, including CPQ or other software, with evidence-based comparison matrices, decision slides and conditional recommendations. Investigate beyond corporate websites and LinkedIn through documentation, filings, news, independent reporting and public professional contributions from relevant staff.
---

# Virksomhedsanalyse og leverandørvalg

Respond in the user's language; default to Danish. Build a reusable decision process across industries. Treat CPQ as an example, never a fixed specialization. Research one company deeply or compare several using the same framework. Never promise to find everything or present public research as full due diligence.

## 1. Establish the decision

Use context already supplied. Ask at most 2–3 focused questions in one turn when the answers materially affect the work: decision/use cases, companies and exact products, and non-negotiable constraints. Prefer a brief conversation over a long intake form. Proceed with stated assumptions for optional gaps.

Identify company, legal entity, country, parent/subsidiaries, product, edition, deployment model and relevant geography. Separate vendor health from product fit. Confirm lookalike names and acquisitions before attributing information.

For selection, establish must-have requirements and meaningful criteria before scoring. Capture current systems, integrations, operating model, implementation capacity, time horizon and budget if known. If needs are unclear, first produce a broad factual landscape and propose criteria; withhold an overall winner until the basis is meaningful. Never assume requirements from an earlier unrelated project.

Read [research-framework.md](references/research-framework.md) for research dimensions and search tactics. Read [decision-deliverables.md](references/decision-deliverables.md) for matrix, scoring and slides.

## 2. Plan and conduct deep research

Use current web research, not model recall, for company and product claims. Begin with authoritative records and primary product material, then seek independent corroboration and contrary evidence. Read underlying pages/documents; search snippets are leads only. Follow meaningful source trails rather than stopping at the homepage or LinkedIn company page.

For each company investigate relevant dimensions: ownership and financial condition; products and actual capabilities; target customers and positioning; implementations and integrations; pricing and total cost; service and partner ecosystem; strategy and recent changes; risks and alternatives. Adapt to the sector and decision. Give comparable research effort and the same core questions to each company; record uneven evidence availability.

Investigate public professional articles, talks, webinars, repositories and posts by relevant executives, product leaders, architects and specialists. Verify role and date. Use these to discover capabilities, strategy and constraints, then corroborate material claims. Distinguish personal opinion from an official commitment. Exclude private personal information and unsupported personality judgments. Respect access limits; disclose unavailable sources and never claim to have read blocked LinkedIn pages or paywalled articles.

Search for disconfirming evidence, limitations, discontinued products, acquisitions, implementation difficulties and changes in strategy. Do not equate absence of criticism with absence of risk. Attribute allegations and assess their credibility; avoid amplifying unsupported accusations.

## 3. Maintain an evidence ledger

Record material claims while researching, with stable IDs such as E001. Capture claim, entity/product/version, source title and direct URL, publisher, publication/update date, access date, relevant passage or paraphrase, evidence type, confidence and limitations. Keep quotes short and comply with source quotation limits.

Use these evidence types: authoritative record; vendor documentation; vendor marketing/case study; independent reporting or evaluation; employee professional contribution; user review/anecdote; analyst inference. Confidence is separate from source type: assess authority for this exact claim, recency, specificity, independent corroboration and contradictions. Explain confidence rather than assigning spurious numeric probabilities.

Trace repeated articles to their original source. A syndicated press release and its copies are one claim origin, not independent corroboration. Vendor-hosted testimonials remain vendor-selected evidence. Reviews and review rankings provide signals, not representative proof. Never infer a whole capability from a logo, partnership badge or job advertisement.

Separate documented facts, attributed claims, inferences and unknowns. Mark missing information as “Ikke dokumenteret offentligt” or “Skal valideres”; never as a negative factual finding. Distinguish standard capability, paid add-on, partner delivery, custom development and roadmap. Record conflicts explicitly, investigate more recent or authoritative sources, and retain unresolved uncertainty.

For material contested or surprising claims, seek a second independent origin. An authoritative filing or precise current technical document can support a fact alone when appropriate; state remaining limitations. Never invent a second source to satisfy a quota.

## 4. Compare and challenge conclusions

Apply consistent criteria, periods, scope and units. Separate product, edition, region and delivery partner. Use comparable financial periods and currencies, and distinguish consolidated from subsidiary figures. Do not estimate private pricing, revenue or implementation costs as facts.

Separate fit scores from evidence confidence. Do not silently score unknowns as zero or normalize them away. Apply must-have gates before ranking. Use weights only when grounded in user priorities; label proposed weights as provisional. Show how reasonable changes in weights or unresolved requirements affect the recommendation.

Investigate what would change the decision. For every major risk or unknown, formulate a precise vendor question and, where useful, a scripted demo, reference call or proof-of-concept acceptance test. Never contact vendors or individuals without explicit authorization.

Recommend a company only when needs and evidence justify it. Explain decisive tradeoffs, conditions, alternatives and confidence. Conclude that there is insufficient evidence when appropriate, then identify the smallest next step that resolves the decision.

## 5. Produce reviewable outputs

Default for a comparison to a concise decision summary, an editable spreadsheet matrix with evidence ledger and an editable slide deck when the user requests comparison in slides and a matrix. For single-company research adapt the output to the request. Use the relevant spreadsheet/presentation skills for actual files and the applicable storage workflow. Never claim files exist when only an outline was produced.

Keep sources attached to claims in the matrix and on the relevant slides; use an appendix for detail, not as a substitute for claim-level traceability. Include research cutoff date, scope, limitations, open questions and recommendation conditions. Summarize decision relevance rather than dumping collected material.

Before delivery check every decisive claim against a source actually read, consistency across ledger/matrix/slides, arithmetic and weights, unresolved contradictions, product scope, missing evidence and balance of research effort. Visually inspect generated slides and inspect spreadsheet formulas using the artifact skills. Do not claim a guaranteed or perfect result.

On updates reuse the prior ledger, check source freshness and entity/product changes, and record what changed and its effect on the decision. Do not schedule monitoring unless requested.
