# Research framework

## Research dimensions

Select dimensions that affect the task; mark others out of scope explicitly.

| Dimension | Investigate | Useful source types |
|---|---|---|
| Identity and ownership | Legal entity, parent, subsidiaries, investors, acquisition history | Company registries, filings, annual reports, transaction announcements |
| Financial resilience | Revenue, profitability, cash/debt where available, trend, funding dependency | Audited reports and authoritative filings; label unavailable data |
| Positioning | Target segments, regions, differentiation, route to market | Product pages, strategy interviews, professional talks, independent industry coverage |
| Product capability | Exact supported workflows, limits, edition, version, availability | Documentation, API reference, release notes, support articles, demos |
| Architecture and integration | APIs, authentication, data ownership, supported connectors, deployment, migration, exit/export | Technical documentation, partner documentation, architecture talks |
| Implementation | Roles, configuration effort, custom code, typical dependencies, training | Detailed cases, implementation partners, references; avoid universal timelines from anecdotes |
| Customers and ecosystem | Comparable customers, deployment scale, partner capacity, support | Specific dated case studies, independently validated references, partner directories |
| Commercial model | Licence metric, minimums, add-ons, renewals, implementation and operations | Published terms and pricing, quotes supplied by user; distinguish estimates |
| Risk and governance | Security, certifications and their scope, regulatory fit, lock-in, support commitments | Trust centre, certificate details, contracts, status/incident pages, authoritative records |
| People and strategy | Relevant leaders and specialists, public technical viewpoints, organizational changes | Public professional posts, webinars, interviews, engineering blogs |
| Recent developments | Product changes, acquisitions, departures, customer events, independent reporting | Dated releases, primary announcements and credible reporting |

Do not treat certifications as proof of every requirement or absence from public documentation as lack of compliance.

## Search sequence

1. Resolve identity and product scope. Search company name with legal entity, ownership and annual report terms in relevant local languages.
2. Map official sources: documentation, pricing, release notes, API, support, trust centre, customer stories, partners and investor material.
3. Search company/product + relevant criterion: integration name, limitation, implementation, migration, export, retirement, acquisition and incident.
4. Identify relevant public professionals from reliable company pages and credited publications. Search name + company/product + interview, webinar, architecture or presentation. Treat employment history as dated, not necessarily current.
5. Search independent trade press, customer technical accounts and credible evaluations. Use user reviews as leads for recurring issues and test those issues against current evidence.
6. Investigate contradictions and requirements with sparse evidence, giving competitors equivalent opportunities to demonstrate capabilities.
7. Stop when decision-critical dimensions have sufficient evidence or a clear documented access gap, contradictions are resolved or exposed, and additional searches produce little decision-relevant information. Describe remaining gaps rather than claiming exhaustive coverage.

Use current search and the stronger search engine where coverage is weak, facts conflict or authoritative sourcing is necessary. Follow applicable browsing instructions. Do not rely on secondary technical descriptions when primary technical documentation is available.

## Example: CPQ as one application

Investigate bundles/services and SKU properties, configuration rules, recurring and consumption pricing, currencies, approvals, quote generation, renewal/amendment workflows, CRM/ERP integration and API coverage. For a named Business Central integration verify the exact connector, supplier, supported objects, direction of synchronization and handling of failures. Distinguish generic ERP integration claims from demonstrated support. Include these dimensions only if relevant to the actual user's needs.
