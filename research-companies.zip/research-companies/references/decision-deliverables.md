# Decision deliverables

## Editable matrix

Prefer an XLSX workbook for comparison unless the user requests another format. Use these sheets when appropriate:

- Beslutningsgrundlag: purpose, scope, entities/products, date, assumptions and user requirements.
- Sammenligning: rows for criteria; parallel vendor columns for finding, fit, confidence and evidence IDs. Include weight, must-have status and outstanding validation.
- Kilder: evidence ledger with direct URLs and dates.
- Omkostninger: comparable licence, implementation, integration, internal effort, ongoing maintenance and exit assumptions. Use ranges only with a documented basis; show currency, period, tax basis and unknowns.
- Afklaringer: question, relevant vendor, decision impact, evidence gap and demo/POC acceptance criterion.

If too many vendor columns hinder readability, use normalized long-format data and a readable summary sheet. Preserve editability and traceability.

## Scoring

Use plain-language findings unless scoring adds decision value. For scoring agree on anchored meanings, for example 1 = confirmed material mismatch, 3 = meets stated requirement with documented conditions, 5 = exceeds the requirement in a way relevant to the user. Define intermediate values and avoid rewarding irrelevant features.

Keep “Ukendt” outside the numeric scale. Show evidence confidence as Høj/Middel/Lav with an explanation. Separate a failed mandatory requirement from an unverified mandatory requirement. The latter requires validation rather than a confident exclusion or pass.

Normalize agreed weights to 100%. Where every material criterion is assessed, weighted score = sum(weight × score) / sum(weight). Where unknowns remain, do not present an apparently complete ranking based only on known criteria. Show coverage and provisional scenarios or justified bounds for unresolved scores. Explain that score bounds are possibilities, not predictions. Keep mandatory gates visible even when calculating totals.

Test sensitivity to plausible weights and critical unknowns. If the winner changes easily, describe the choice as conditional and name the resolving evidence. Never use false precision to hide uncertainty.

## Decision slides

Adapt length to the task; default to about 6–8 substantive slides plus a source appendix:

1. Decision and scope, with research cutoff date.
2. Needs, use cases, non-negotiable requirements and criteria.
3. Comparable vendor/product profiles.
4. Decision-critical differences and capability evidence.
5. Implementation, integration and total-cost findings.
6. Risks, uncertainty and evidence coverage.
7. Conditional recommendation and sensitivity; no winner if unjustified.
8. Vendor questions, demo/POC tests and next steps.

Merge slides where needed. Give each slide a clear takeaway supported by evidence, and use actual comparisons rather than decorative company descriptions. Include short clickable sources or source IDs on the relevant slide and complete references in the appendix. Do not imply a vendor claim is independently verified through polished wording.

## Final verification

- Trace decisive claims from slides to matrix to original source.
- Ensure unknowns and contradictions survive summarization.
- Verify exact company, product edition, dates, currencies, units and periods.
- Verify formulas, weight totals, mandatory gates and consistency of recommendations.
- Ensure all vendors were assessed on the same criteria and evidence gaps are visible.
- Inspect actual rendered slides and generated workbook according to their artifact skills.
