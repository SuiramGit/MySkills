#!/usr/bin/env python3
"""Enforce the user's 10 pt table-content rule, including nested tables."""
import argparse
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

def set_size(pr):
    for tag in ('sz', 'szCs'):
        el = pr.find(qn('w:' + tag))
        if el is None:
            el = OxmlElement('w:' + tag)
            pr.append(el)
        el.set(qn('w:val'), '20')

def normalize(doc):
    for table in doc.tables:
        for p in table._tbl.iter(qn('w:p')):
            pr = p.get_or_add_pPr()
            rpr = pr.find(qn('w:rPr'))
            if rpr is None:
                rpr = OxmlElement('w:rPr')
                pr.append(rpr)
            set_size(rpr)
        for run in table._tbl.iter(qn('w:r')):
            set_size(run.get_or_add_rPr())

def check(doc):
    errors = []
    for ti, table in enumerate(doc.tables):
        for pi, p in enumerate(table._tbl.iter(qn('w:p'))):
            rpr = p.find(qn('w:pPr') + '/' + qn('w:rPr'))
            for tag in ('sz', 'szCs'):
                el = None if rpr is None else rpr.find(qn('w:' + tag))
                if el is None or el.get(qn('w:val')) != '20':
                    errors.append(f'Table {ti+1}, paragraph {pi+1}: typing size {tag} must be explicit 10 pt')
            for run in p.iter(qn('w:r')):
                if not ''.join(run.itertext()).strip():
                    continue
                for tag in ('sz', 'szCs'):
                    el = run.find(qn('w:rPr') + '/' + qn('w:' + tag))
                    if el is None or el.get(qn('w:val')) != '20':
                        text = ''.join(t.text or '' for t in run.iter(qn('w:t')))
                        errors.append(f'Table {ti+1}, paragraph {pi+1}: {tag} not 10 pt: {text[:70]}')
    if errors:
        raise ValueError('\n'.join(errors))
    return 'PASS: all table paragraphs and text runs use 10 pt, including nested tables.'

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('docx')
    ap.add_argument('--fix', action='store_true')
    args = ap.parse_args()
    doc = Document(args.docx)
    if args.fix:
        normalize(doc)
        doc.save(args.docx)
        doc = Document(args.docx)
    print(check(doc))
