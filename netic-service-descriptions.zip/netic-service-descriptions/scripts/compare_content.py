#!/usr/bin/env python3
"""Flag changes by field for human/source review; never approve semantic equivalence."""
import argparse,json,re
from collections import Counter
from docx import Document
NS='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
def fields(path):
 d=Document(path)
 return {r.cells[0].text.strip():' '.join(t.text or '' for t in r.cells[1]._tc.iter(NS+'t')) for r in d.tables[0].rows}
def compare(a,b):
 result=[]
 for key in sorted(set(a)|set(b)):
  old,new=a.get(key,''),b.get(key,'')
  if old==new:continue
  flags=[]
  patterns={
   'numbers_units':r'\d+(?:[.,]\d+)*(?:\s*(?:%|GB|TB|MB|CPUs?|points?|hours?|days?|months?|years?|users?))?',
   'commitment_scope':r'\b(?:may|must|will|can|only|unless|not|never|always|up to|at least|maximum|minimum|subject to|supports?|guarantees?|included|optional)\b',
   'rasci_fee_marks':r'(?<!\w)(?:R|A|S|C|I|x)(?!\w)'
  }
  for name,pattern in patterns.items():
   if Counter(re.findall(pattern,old,re.I))!=Counter(re.findall(pattern,new,re.I)):flags.append(name)
  result.append({'field':key,'flags':flags,'before':old,'after':new,
                 'review':'Expected current-quarter metadata change; verify date' if key=='Service Version' else 'Source comparison required'})
 return {'changed_fields':result,'semantic_review_required':True}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('before');p.add_argument('after');p.add_argument('--output');a=p.parse_args()
 s=json.dumps(compare(fields(a.before),fields(a.after)),ensure_ascii=False,indent=2)
 if a.output:
  from pathlib import Path
  Path(a.output).write_text(s)
 else:print(s)
