#!/usr/bin/env python3
"""Build editable Netic catalogue descriptions; never supply service facts."""
import argparse
import json
import re
import shutil
import subprocess
from pathlib import Path
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT, WD_ROW_HEIGHT_RULE
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

ROOT = Path(__file__).resolve().parents[1]
WIDTH = 450
LABELS = ['Service Name', 'Service ID', 'Service Version', 'Service Offerings',
          'Bundling and tiering', 'Normal Operating Time', 'Service Level Agreements',
          'Responsibilities', 'Price Model (based on the cost drivers of the corresponding Technical Services and Configuration Items)']
SLA_LABELS = {'availability': 'Availability (of the service within the normal operating time) SLA: ',
              'response': 'Response time SLA: ', 'resolution': 'Resolution time SLA: ', 'other': 'Other SLA: '}
IMPLEMENTATION = ['n/a', 'Included in all implementation fees of any Managed Services delivered by Netic',
                  'Included in the implementation fees of specified Managed Services',
                  'Contract dependent: T&M, fixed price per service, fixed price implementation']
RECURRING = ['n/a', 'Included in all recurring fees of any Managed Services delivered by Netic',
             'Included in the recurring fees of specified Managed Services',
             'Consumption-based recurring fee, i.e. variable fee',
             'Subscription-based recurring fee, i.e. fixed monthly fee', 'T&M']


def set_attr(parent, tag, attrs):
    node = parent.find(qn('w:' + tag))
    if node is None:
        node = OxmlElement('w:' + tag)
        parent.append(node)
    for k, v in attrs.items():
        node.set(qn('w:' + k), str(v))
    return node


def evidence_paths(d):
    paths = ['service_name', 'service_id', 'service_version', 'catalogue_number', 'service_owner', 'operating_time', 'related_technical_services']
    paths += ['sla.' + k for k in SLA_LABELS]
    for key in ('offerings', 'bundling', 'responsibilities', 'price_details'):
        paths += [f'{key}.{i}' for i in range(len(d.get(key, [])))]
    paths += ['implementation_fee', 'recurring_fee']
    return paths


def validate(d):
    if d.get('unresolved_questions') != []:
        raise ValueError('Resolve all questions before generation; unresolved_questions must be [].')
    for key in ['service_name', 'service_id', 'service_version', 'operating_time']:
        if not isinstance(d.get(key), str) or (not d[key].strip() and key not in d.get('authorised_placeholders', [])):
            raise ValueError(f'Missing {key}; ask the user.')
    if 'catalogue_number' not in d:
        raise ValueError('Confirm the catalogue number or explicit omission (null).')
    if d['catalogue_number'] is not None and not re.fullmatch(r'\d+\.\d+', str(d['catalogue_number'])):
        raise ValueError('catalogue_number must be null or a number such as 10.14.')
    for key in ['offerings', 'bundling', 'responsibilities']:
        if not isinstance(d.get(key), list) or not d[key]:
            raise ValueError(f'Missing {key}; ask the user.')
    for key in ['service_owner', 'related_technical_services']:
        if not isinstance(d.get(key), str) or (not d[key].strip() and key not in d.get('authorised_placeholders', [])):
            raise ValueError(f'Missing {key}; confirm the value or a blank.')
    for key in SLA_LABELS:
        if not isinstance(d.get('sla', {}).get(key), str) or not d['sla'][key].strip():
            raise ValueError(f'Missing SLA {key}; n/a is not an automatic default.')
    if d.get('supplier_label', 'The Supplier') not in ('The Supplier', 'Netic'):
        raise ValueError('supplier_label must follow a source variant: The Supplier or Netic.')
    for i, row in enumerate(d['responsibilities']):
        if not row.get('task') or 'supplier' not in row or 'customer' not in row:
            raise ValueError(f'Incomplete responsibility row {i}.')
        # A condition such as S (via add-on) is supported but must be sourced.
        for key in ['supplier', 'customer']:
            if not isinstance(row[key], str):
                raise ValueError(f'Role {key} in row {i} must be a string, including confirmed blanks.')
    for key, count in [('implementation_fee', 4), ('recurring_fee', 6)]:
        if not isinstance(d.get(key), list) or not d[key]:
            raise ValueError(f'Missing {key}.')
        if d.get('pricing_variant', 'standard') == 'standard' and len(d[key]) != count:
            raise ValueError(f'{key} must retain all {count} standard alternatives.')
        if d.get('pricing_variant', 'standard') != 'standard':
            raise ValueError('Use the native template pricing layout; historical variants are not the current template.')
        for row in d[key]:
            if row.get('mark') not in ('', 'x', '(x)') or not row.get('text'):
                raise ValueError(f'Invalid {key} row: require mark and text.')
            if row['mark'] and ('<which ones>' in row['text'] or 'specified Managed Services' in row['text']):
                raise ValueError(f'Selected {key} inclusion must name the actual services.')
        if not any(row['mark'] for row in d[key]) and not d.get(key + '_note'):
            raise ValueError(f'{key} needs confirmed selections or a sourced explanatory note.')
    evidence = d.get('evidence', {})
    for path in evidence_paths(d):
        e = evidence.get(path, {})
        if not e.get('source') or not e.get('support'):
            raise ValueError(f'Missing source locator/support for {path}.')
    for key in ('implementation_fee_note', 'recurring_fee_note'):
        if d.get(key) and not all(d.get('evidence', {}).get(key, {}).get(x) for x in ('source', 'support')):
            raise ValueError(f'Missing evidence for {key}.')
    if d.get('operation') not in ('new', 'revise', 'reproduce'):
        raise ValueError('operation must be new, revise or reproduce.')
    index = json.loads((ROOT / 'references/catalogue-index.json').read_text())
    if d['operation'] == 'new':
        for entry in index:
            if d['service_id'] == entry['id'] or d['catalogue_number'] == entry['number']:
                raise ValueError(f'New service collides with {entry["id"]}; clarify identity or use revise/reproduce.')
    for key in ['offerings', 'bundling', 'price_details']:
        for block in d.get(key, []):
            validate_block(block)
    # Unknowns cannot be disguised as a final document. A specific user-authorised
    # placeholder needs an exact path plus source evidence, checked by the author.
    def walk(value, path=''):
        if isinstance(value, dict):
            for key, item in value.items():
                if key not in ('evidence', 'authorised_placeholders'):
                    walk(item, f'{path}.{key}'.strip('.'))
        elif isinstance(value, list):
            for i, item in enumerate(value): walk(item, f'{path}.{i}')
        elif isinstance(value, str) and re.search(r'\bTODO\b|\bTBD\b|\[to be confirmed\]|\[afklares\]', value, re.I):
            if path not in d.get('authorised_placeholders', []):
                raise ValueError(f'Unauthorised placeholder at {path}.')
    walk(d)


def validate_block(block):
    if isinstance(block, str):
        if not block.strip(): raise ValueError('Empty text block.')
        return
    kind = block.get('type', 'p')
    if kind == 'bullet' and block.get('level', 1) not in (1, 2, 3):
        raise ValueError('Bullet level must be 1, 2 or 3.')
    for key in ('space_after', 'space_before'):
        if key in block and (not isinstance(block[key], (int, float)) or not 0 <= block[key] <= 24):
            raise ValueError('Paragraph spacing must be 0-24 points.')
    if kind in ('p', 'heading', 'bullet') and not block.get('text'):
        raise ValueError('Empty paragraph block.')
    elif kind == 'table':
        count = len(block.get('headers', []))
        if not count or not block.get('rows') or any(len(r) != count for r in block['rows']):
            raise ValueError('Invalid nested table dimensions.')
        if block.get('widths') and (len(block['widths']) != count or any(x <= 0 for x in block['widths'])):
            raise ValueError('Invalid table widths.')
    elif kind == 'image':
        if not block.get('path') or not Path(block['path']).is_file():
            raise ValueError('Missing supplied illustration.')
    elif kind not in ('p', 'heading', 'bullet'):
        raise ValueError(f'Unsupported block type: {kind}')


# Populate the supplied native template. Never rebuild its layout from the PDF.
from copy import deepcopy
from docx.table import Table, _Row
from docx.text.paragraph import Paragraph

TEMPLATE = ROOT / 'assets/netic-service-template.docx'
FIELD_ROWS = {'service_name': 0, 'service_id': 1, 'service_version': 2,
              'service_owner': 3, 'offerings': 4, 'bundling': 5,
              'operating_time': 6, 'sla': 7, 'responsibilities': 8,
              'related_technical_services': 9, 'pricing': 10}


def ensure_reference_fonts():
    if not shutil.which('fc-cache'):
        return
    dest = Path.home() / '.local/share/fonts/netic-native'
    dest.mkdir(parents=True, exist_ok=True)
    for font in (ROOT / 'assets/fonts').glob('Roboto*.ttf'):
        shutil.copy2(font, dest / font.name)
    subprocess.run(['fc-cache', '-f', str(dest)], check=True, capture_output=True)


def replace_text(p, text, *, bold=None):
    """Keep paragraph and run properties from this exact template location."""
    pr = deepcopy(p._p.pPr) if p._p.pPr is not None else None
    run_pr = next((deepcopy(r._r.rPr) for r in p.runs if r._r.rPr is not None and r.text), None)
    # Empty template paragraphs store their intended typing format in pPr/rPr.
    if run_pr is None and pr is not None:
        fmt = pr.find(qn('w:rPr'))
        if fmt is not None:
            run_pr = deepcopy(fmt)
    p.clear()
    r = p.add_run(text)
    if run_pr is not None:
        r._r.insert(0, run_pr)
    if bold is not None:
        r.bold = bold
    return p


def clear_cell(cell):
    for child in list(cell._tc):
        if child.tag != qn('w:tcPr'):
            cell._tc.remove(child)


def add_p(cell, proto, text='', *, bold=None, heading=False):
    node = deepcopy(proto._p)
    cell._tc.append(node)
    p = Paragraph(node, cell)
    replace_text(p, text, bold=bold)
    if heading:
        p.paragraph_format.keep_with_next = True
    return p


def populate_blocks(cell, blocks, proto):
    clear_cell(cell)
    for i, block in enumerate(blocks):
        if isinstance(block, str):
            block = {'type': 'p', 'text': block}
        kind = block.get('type', 'p')
        if kind in ('p', 'heading', 'bullet'):
            p = add_p(cell, proto, block['text'], bold=True if kind == 'heading' else None, heading=kind == 'heading')
            # Retain the field's font, alignment and line spacing. Only paragraph
            # separation is content-dependent; do not import formatting from drafts.
            if i:
                p.paragraph_format.space_before = Pt(6)
            if kind == 'bullet':
                p.paragraph_format.left_indent = Pt(18 * block.get('level', 1))
            for k in ('space_before', 'space_after'):
                if k in block:
                    setattr(p.paragraph_format, k, Pt(block[k]))
        elif kind == 'table':
            sample = Document(TEMPLATE).tables[0].rows[8].cells[1].tables[0]
            rows = [block['headers']] + block['rows']
            t = clone_table(cell, sample, rows)
            ratios = block.get('widths', [1] * len(rows[0]))
            if len(rows[0]) != 3:
                raise ValueError('Custom tables currently require three columns; use paragraphs or extend template-aware support.')
            for col, ratio in zip(t.columns, ratios):
                col.width = Pt(316.5 * ratio / sum(ratios))
            for row in t.rows:
                for c, ratio in zip(row.cells, ratios):
                    c.width = Pt(316.5 * ratio / sum(ratios))
        elif kind == 'image':
            p = add_p(cell, proto)
            p.add_run().add_picture(block['path'], width=Pt(316.5))
            if block.get('caption'):
                add_p(cell, proto, block['caption'])
    if not cell.paragraphs or cell._tc[-1].tag != qn('w:p'):
        add_p(cell, proto)


def clone_table(cell, sample, values):
    node = deepcopy(sample._tbl)
    cell._tc.append(node)
    t = Table(node, cell)
    # Preserve header/body cell formatting, widths and borders from native rows.
    prototypes = [deepcopy(r._tr) for r in t.rows]
    for row in list(t._tbl.tr_lst):
        t._tbl.remove(row)
    for i, texts in enumerate(values):
        tr = deepcopy(prototypes[min(i, len(prototypes) - 1)])
        t._tbl.append(tr)
        row = _Row(tr, t)
        set_attr(tr.get_or_add_trPr(), 'cantSplit', {'val': 1})
        for c, text in zip(row.cells, texts):
            proto = c.paragraphs[0]
            clear_cell(c)
            add_p(c, proto, text)
    return t


def current_version(now=None):
    from datetime import datetime
    from zoneinfo import ZoneInfo
    now = now or datetime.now(ZoneInfo("Europe/Copenhagen"))
    return f"{now.year} Q{(now.month - 1) // 3 + 1} Version"


def apply_version(d):
    d['service_version'] = current_version()
    d.setdefault('evidence', {})['service_version'] = {
        'source': 'Standing user instruction: current quarter and year in Europe/Copenhagen',
        'support': d['service_version']}
    return d


def build(d, output):
    d = apply_version(dict(d))
    ensure_reference_fonts()
    doc = Document(TEMPLATE)
    original = Document(TEMPLATE)
    outer = doc.tables[0]
    title = (str(d.get('catalogue_number')) + ' ' if d.get('catalogue_number') else '') + d['service_name']
    replace_text(doc.paragraphs[0], title)
    # Definitions hyperlink, document styles and page geometry remain untouched.
    for key in ('service_name', 'service_id', 'service_version', 'service_owner',
                'operating_time', 'related_technical_services'):
        c = outer.rows[FIELD_ROWS[key]].cells[1]
        proto = c.paragraphs[0]
        clear_cell(c)
        add_p(c, proto, d.get(key, ''))
    for key in ('offerings', 'bundling'):
        c = outer.rows[FIELD_ROWS[key]].cells[1]
        populate_blocks(c, d[key], original.tables[0].rows[FIELD_ROWS[key]].cells[1].paragraphs[0])
    sla = outer.rows[7].cells[1]
    protos = original.tables[0].rows[7].cells[1].paragraphs
    clear_cell(sla)
    for (key, label), proto in zip(SLA_LABELS.items(), protos):
        add_p(sla, proto, label + d['sla'][key])
    c = outer.rows[8].cells[1]
    sample = original.tables[0].rows[8].cells[1]
    clear_cell(c)
    intro = add_p(c, sample.paragraphs[0], sample.paragraphs[0].text)
    intro.paragraph_format.keep_with_next = True
    add_p(c, sample.paragraphs[1])
    values = [['Task', d.get('supplier_label', 'The Supplier'), 'The Customer']]
    values += [[r['task'], r['supplier'], r['customer']] for r in d['responsibilities']]
    t = clone_table(c, sample.tables[0], values)
    set_attr(t.rows[0]._tr.get_or_add_trPr(), 'tblHeader', {'val': 1})
    add_p(c, sample.paragraphs[-1])
    c = outer.rows[10].cells[1]
    sample = original.tables[0].rows[10].cells[1]
    clear_cell(c)
    for index, key, label in [(0, 'implementation_fee', 'Implementation fee:'),
                              (1, 'recurring_fee', 'Recurring fee:')]:
        p = add_p(c, sample.paragraphs[index * 2], label, bold=True)
        p.paragraph_format.keep_with_next = True
        clone_table(c, sample.tables[index], [[r['mark'], r['text']] for r in d[key]])
        add_p(c, sample.paragraphs[index * 2 + 1])
        if d.get(key + '_note'):
            add_p(c, sample.paragraphs[index * 2 + 1], d[key + '_note'])
    # Price detail blocks belong inside Price Model, never in a new outer section.
    for block in d.get('price_details', []):
        if isinstance(block, str):
            block = {'type': 'p', 'text': block}
        p = add_p(c, sample.paragraphs[-1], block['text'],
                  bold=True if block.get('type') == 'heading' else None,
                  heading=block.get('type') == 'heading')
        if block.get('type') == 'heading':
            p.paragraph_format.space_before = Pt(6)
    doc.core_properties.title = title
    doc.core_properties.subject = 'Netic service description'
    doc.core_properties.author = 'Netic A/S'
    doc.core_properties.comments = ''
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    from check_typography import normalize, check
    normalize(doc)
    doc.save(output)
    check(Document(output))
    return output


def extract_existing(source):
    """Restyle only. Existing values and approved blanks are not reinterpreted."""
    src = Document(source)
    if len(src.tables) != 1:
        raise ValueError('Restyle requires one outer service table.')
    fields = {r.cells[0].text.strip(): r.cells[1] for r in src.tables[0].rows}
    required = ['Service Name','Service ID','Service Version','Service Offerings',
                'Bundling and tiering','Normal Operating Time','Service Level Agreements',
                'Responsibilities', LABELS[-1]]
    missing = set(required) - set(fields)
    if missing:
        raise ValueError(f'Missing source rows: {sorted(missing)}')
    def blocks(c):
        if c.tables:
            raise ValueError('Rich offering tables require explicit JSON migration; do not drop them.')
        if c._tc.xpath('.//w:drawing | .//w:hyperlink'):
            raise ValueError('Rich source content requires explicit migration; do not flatten it.')
        return [{'type': 'heading' if p.paragraph_format.keep_with_next or (p.runs and all(r.bold for r in p.runs if r.text)) else 'p',
                 'text': p.text} for p in c.paragraphs if p.text]
    d = {'service_name':fields['Service Name'].text, 'service_id':fields['Service ID'].text,
         'service_version':fields['Service Version'].text, 'catalogue_number': None,
         'service_owner':'', 'related_technical_services':'',
         'offerings':blocks(fields['Service Offerings']), 'bundling':blocks(fields['Bundling and tiering']),
         'operating_time':fields['Normal Operating Time'].text, 'sla':{}, 'responsibilities':[],
         'price_details':[]}
    if 'Service Accountable (Owner)/(Commercial  responsible)' in fields:
        d['service_owner']=fields['Service Accountable (Owner)/(Commercial  responsible)'].text
    for name in ('Related Technical Services','Related Services'):
        if name in fields:
            d['related_technical_services']=fields[name].text
    # Preserve an existing numbered title.
    title=src.paragraphs[0].text
    match=re.match(r'^(\d+\.\d+)\s+', title)
    if match:
        d['catalogue_number']=match.group(1)
    for p in fields['Service Level Agreements'].paragraphs:
        for key, label in SLA_LABELS.items():
            if p.text.startswith(label):
                d['sla'][key]=p.text[len(label):]
    if set(d['sla']) != set(SLA_LABELS):
        raise ValueError('SLA layout requires explicit migration.')
    rasci=fields['Responsibilities'].tables[0]
    d['supplier_label']=rasci.rows[0].cells[1].text.strip()
    for r in rasci.rows[1:]:
        d['responsibilities'].append(dict(zip(('task','supplier','customer'),(c.text for c in r.cells))))
    pricing=fields[LABELS[-1]]
    if len(pricing.tables) != 2:
        raise ValueError('Expected implementation and recurring fee tables.')
    for key,t in zip(('implementation_fee','recurring_fee'),pricing.tables):
        rows=t.rows
        if rows and rows[0].cells[0]._tc is rows[0].cells[1]._tc:
            rows=rows[1:]  # Legacy generated table has a merged heading row.
        d[key]=[{'mark':r.cells[0].text, 'text':r.cells[1].text} for r in rows]
    for p in pricing.paragraphs:
        if p.text.strip() and p.text.strip() not in ('Implementation fee:', 'Recurring fee:'):
            d['price_details'].append({'type':'heading' if p.paragraph_format.keep_with_next else 'p','text':p.text})
    return d


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--data',type=Path)
    group.add_argument('--restyle',type=Path,help='Migrate an existing description without changing its facts.')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.restyle:
        data=extract_existing(args.restyle)
    else:
        data=json.loads(args.data.read_text())
        apply_version(data)
        validate(data)
    print(build(data,args.output))


if __name__ == '__main__':
    main()
