#!/usr/bin/env python3
"""Report language review candidates; never infer facts or rewrite commitments."""
import argparse,json,re
from docx import Document
PATTERNS={
 'party_voice':r'\b(?:we|our|ours|you|your)\b',
 'promotional_claim':r'\b(?:robust|seamless(?:ly)?|comprehensive|cutting-edge|enterprise-grade|best-in-class)\b',
 'absolute_claim':r'\b(?:guarantee\w*|always|never|ensures?|all|every|zero downtime)\b',
 'modal_review':r'\b(?:shall|must|will|may|can|should|supports?|designed to|up to|subject to|unless)\b',
 'draft_marker':r'\b(?:to be clarified|to be confirmed|TBD|TODO)\b',
}
def review(doc):
 result=[]
 # XML traversal visits nested table paragraphs exactly once and includes hyperlinks.
 for i,p in enumerate(doc.element.body.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p'),1):
  text=''.join(t.text or '' for t in p.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t'))
  if not text.strip():continue
  hits={name:sorted(set(re.findall(pattern,text,re.I))) for name,pattern in PATTERNS.items() if re.search(pattern,text,re.I)}
  if len(text.split())>80:hits['long_paragraph']=[str(len(text.split()))+' words; review, not a hard limit']
  if hits:result.append({'paragraph':i,'text':text,'review':hits})
 return {'status':'review_required' if result else 'no_pattern_flags','semantic_audit_required':True,'findings':result}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('docx');p.add_argument('--output')
 a=p.parse_args();s=json.dumps(review(Document(a.docx)),ensure_ascii=False,indent=2)
 if a.output:
  from pathlib import Path
  Path(a.output).write_text(s)
 else:print(s)
