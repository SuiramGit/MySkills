# Netic catalogue language profile

## Basis and limits

Source: user-supplied Merged documents - all services in - 2026 Q4 Version(2).pdf,
219 pages, 62 services across all 11 service groups. Its bytes match the retained
assets/netic-service-catalogue-2026-q4.pdf (SHA-256
b82b97aa09b56371052ad24ee0b4b7d94cd96039b409504b49198ce36bf09de4).
The service texts and page index are already bundled under references/.

The catalogue has a recognisable structure but not one uniform editorial voice.
Some entries use Netic, others we/our/you, and others the Supplier/the Customer.
It also contains promotional claims and grammatical defects. The rules below
separate observed conventions from editorial normalisation. Do not claim every
rule occurs consistently in the source. Never reuse example service facts.

## Evidence and resulting rules

| Source locator | Observed pattern | Rule for new descriptions |
| --- | --- | --- |
| BS.FND.CM, pp. 9–14; BS.FND.SRQM, pp. 25–27 | Opening defines a process, followed by activities and conditions | Start with what the service delivers, the managed object and its scope |
| BS.SCM.DR, pp. 44–46 | Definition followed by descriptive activity headings | Organise detailed offerings under short, factual headings |
| BS.SCM.CAPA, pp. 38–40 | Distinguishes dedicated customer resources from shared infrastructure | State ownership and management boundaries explicitly when evidenced |
| BS.CON.AM, pp. 156–158; BS.CON.AO, pp. 159–161 | Planned maintenance is distinguished from active monitoring and incident response | Keep adjacent services and operational responsibilities distinct |
| BS.CON.CACHE, pp. 184–187; BS.CON.DB, pp. 191–194 | Deployment options, conditions and customer/platform responsibilities | Describe variants before their limitations; do not generalise one variant to all tiers |
| BS.CON.CONREG, pp. 188–190; BS.CON.GIT, pp. 195–197 | “The Supplier (Netic)” and customer-hosted versus Netic-hosted options | Use one consistent party vocabulary and explicit hosting scope |
| BS.APP.3RDPARTY, pp. 214–216; BS.APP.CUSTOM, pp. 217–219 | Tier-specific monitoring and incident hours; separate software development | Keep monitoring, response hours and service availability separate |
| BS.SCM.RESTOR, pp. 54–56 | Customer acceptance and alternative restore conditions qualify the action | Preserve prerequisites and exceptions next to the action |
| BS.FND.ASSET, pp. 6–8; BS.CON.OBSERV, pp. 180–183 | Technical terms expanded or explained alongside their purpose | Explain an acronym at first meaningful use when its meaning is certain |
| Across entries: Responsibilities and Price Model | Task verbs and explicit fee categories/units | Use action–object RASCI task labels and precise billing descriptions |

Corpus scan (case-insensitive whole words in extracted full text, including
tables): provides 114; includes 91; may 13; must 15; will 29; shall 0.
These counts support a descriptive present-tense voice. They are not quotas.

## Editorial standard

1. Write formal, plain English for customers and service reviewers. Default to
   British spelling (organisation, centralised, licence as noun), an editorial
   choice resolving mixed source spelling. Preserve product names, official
   service names, IDs, template labels and quoted contractual wording exactly.
2. Open Service Offerings with one short paragraph defining delivery and scope.
   A useful pattern is “The [service] provides [delivery] for [managed object].”
   Do not force that wording on every entry or add an unsupported business benefit.
3. Use the service/platform as subject for capabilities and the Supplier/the
   Customer for actions and responsibilities. Introduce “The Supplier (Netic)”
   only when useful, then use “the Supplier” consistently. Retain a deliberately
   selected Netic variant, including its RASCI header. Avoid switching to we/you.
4. Prefer concrete verbs: provides, includes, manages, configures, monitors,
   maintains, restores. Use present tense for confirmed delivery. Do not turn
   “supports” or “can” into an obligation to perform the action.
5. Use short descriptive headings and parallel lists of comparable items.
   Sentence case is the editorial default for new internal headings; preserve
   native outer labels. Use prose for conditions and relationships. Detail must
   follow evidence; never pad a thin input to match a long exemplar.
6. Explain what, who, scope and condition. Place each material restriction next
   to the affected capability. Keep included/optional/separately charged features
   distinct; do not infer inclusion from technical compatibility.
7. Use one term per concept: backup (noun/adjective), back up (verb), restore for
   the action and recovery for the broader process where that distinction is
   supported. Preserve Git, GitHub, PostgreSQL and other canonical names.
8. Keep numbers, units, frequency, retention and price basis precise. A monthly
   charge per user is not per active user unless stated. Do not convert points
   to currency. Keep “up to”, “maximum”, “starting at”, “only”, “if” and “unless”.
9. Use RASCI task labels such as “Configure backup schedules” or “Maintain the
   platform”, not benefit claims. A language edit cannot assign or alter roles.
10. Remove empty promotional modifiers where meaning is unchanged. Words such
    as robust, seamless, comprehensive, cutting-edge and enterprise-grade need
    review, not automatic deletion. A sourced technical attribute (for example
    high availability) may be meaningful and must not be removed indiscriminately.

## Modal verbs and commitment protection

| Source meaning | Preserve in output | Unsafe change |
| --- | --- | --- |
| Supported capability | can / supports | will / always |
| Optional or conditional availability | may / optional / subject to [condition] | included / provided by default |
| Mandatory prerequisite | must / is required to | may / should |
| Confirmed future action | will, with its trigger | guaranteed regardless of trigger |
| Objective or design intent | aims to / is designed to | ensures / guarantees |
| Maximum or upper bound | up to / maximum | unconditional target or minimum |

Interpret modal verbs in context, not by a mechanical replacement dictionary.
BS.HSG.COLOC p. 107 uses “may not be shared” as a prohibition and “must be
escorted” as an obligation. BS.SCM.RESTOR p. 54 uses “may not apply” to express
conditional applicability. Preserve that distinction. Keep illustrative markers
such as “such as”, “e.g.” and “typically”; an example list is not exhaustive scope.

Do not use “shall” to make text sound contractual. Do not remove a genuine
obligation merely to achieve a softer tone. Where meaning is unclear, ask.

Further cross-group evidence: BS.HSG.COLOC p. 107 makes access conditions
explicit; BS.NWS.INET p. 122 distinguishes standard and optional connectivity;
BS.STO.SAN p. 131 ties benefits to storage mechanisms; BS.CMP.IMVM p. 138
separates infrastructure from OS management; BS.CMP.OS p. 149 separates 24/7
monitoring from Basic incident handling during working hours. BS.CON.CCP
pp. 162–170 is architecture-led; retain meaningful technical organisation instead
of forcing identical offering paragraphs on all service types.

## Source defects to avoid

- BS.FND.ASSET p. 6: “Each entry in the CMDB are” has subject–verb disagreement.
- BS.SCM.PATCH p. 50: the maturation-period sentence mixes “seek to have” and
  “is observed”. Preserve its uncertainty; do not silently make 14 days mandatory.
- BS.CON.GIT p. 195: the final “cod” is incomplete. Do not guess missing scope.
- BS.SCM.BKUP pp. 34–36: frequency/RPO statements and Gold/Silver versus
  Basic/Standard/Premium labels conflict. This is a factual blocker, not copyediting.
- BS.APP.CUSTOM pp. 217–218: tier names and operating-hour assignments differ between narrative and table. Clarify the intended mapping; do not resolve it by stylistic editing.
- Broad claims such as “seamless”, “secure at every layer” or “ensures” occur in
  the source. Do not inherit guarantees or convert a new service's evidence into them.

## Internal language review required before delivery

Run scripts/check_language.py on the DOCX. It reports editorial candidates only:
a clean report is not proof of fidelity, and warnings are not automatic failures.
Then perform this semantic review against the source map, recording an internal
pass/fix/block decision and evidence for every applicable check:

- Definition: Does the opening accurately name delivery and scope?
- Parties: Are Netic/the Supplier/the Customer used consistently and correctly?
- Modality: Did any capability, intention or option become a promise or duty?
- Scope: Are inclusions, exclusions, prerequisites and tier restrictions preserved?
- Numbers: Are values, units, periods, upper bounds and billing bases unchanged?
- Operations: Are availability, monitoring, response, resolution, RPO and RTO distinct?
- Responsibilities: Does prose agree with RASCI, with no invented allocation?
- Terminology: Are technical terms and official names consistent?
- Readability: Are grammar, parallelism, heading hierarchy and repetition sound?
- Claims: Does every reliability, security, compliance or performance claim have support?
- Draft status: Are authorised blanks and questions still visibly open?

Fix linguistic defects. Stop for unresolved factual changes or contradictions
unless an explicit draft placeholder is authorised. Re-run checks after edits.
No extra user approval is needed for grammar changes that preserve meaning.

For formatting-only requests, run the review as a diagnostic but preserve wording.
Do not silently rewrite service content beyond the requested scope.

## Calibration examples (fictional, not service facts)

Input: “Proxy can be reused if licensing and capacity permit it.”
Accept: “An existing proxy may be reused if licensing and capacity requirements are met.”
Reject: “The service includes reuse of the existing proxy.”

Input: “Hourly backups; retention 185 days.”
Accept: “Backups run hourly and are retained for 185 days.”
Reject: “The service guarantees an RPO of one hour.”

Input: “The Supplier monitors the platform; the Customer manages applications.”
Accept: “The Supplier monitors the platform. The Customer manages the applications.”
Reject: “The Supplier monitors and manages the platform and applications.”

Input: “Up to 99% availability.”
Accept: “Availability: up to 99%.”
Reject: “Availability: at least 99%.”

Input: “Each repository are backed up.”
Accept: “Each repository is backed up.”
This correction changes grammar only.
