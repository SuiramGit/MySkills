# Draft review gates

## Status and intake

Every output is a qualified draft requiring human review. Never call it final,
approved or contract-ready. This does not authorise fabricated facts or arbitrary
placeholders. Preserve the user's field-specific decisions, consolidate questions
and ask only about material unresolved points. Do not ask for current version:
derive YYYY Qn Version from the current client date in Europe/Copenhagen.

The complete 62-service catalogue is reference material, not model training or
proof that the skill behaves correctly. Use small regression examples to verify
the rules; do not require the user to provide more examples for routine checks.

## Content comparison

Before an edit, retain an internal original. Run compare_content.py on the original
and result. It compares per-field text and flags changed numbers/units, modal and
scope markers, and RASCI/fee codes. It always reports changed text, even where
token counts match. A swapped number or reassigned obligation can preserve counts:
inspect the full before/after text and source map, not just flags.

Check prices, units, billing basis, periods, SLA, RPO/RTO, operating/monitoring/
response hours, conditional features and responsibilities. Explain intended
changes in the internal audit. Never silently accept an accidental change.
Current-quarter Service Version changes are expected metadata changes, but still
verify the date and exact format. New drafts use a source-to-output audit instead.

## Visual layout gate

Render every page, inspect at readable resolution and record an internal checklist:
- All table text and typing formats are 10 pt; title and definitions retain their
  specified sizes. Run check_typography.py.
- No clipping, overlap, missing glyphs or text touching/escaping borders.
- No heading alone at the bottom of a page; keep it with at least two following
  lines or move the block together.
- No isolated last word/line at the next page's top where avoidable.
- RASCI and price rows remain intact where short; repeated headers where supported.
- No blank spillover caused by unused template paragraphs, and no avoidable
  empty continuation strips.
- Adequate cell padding, readable spacing, original margins and column widths.
- Never shrink fonts to force fewer pages; let substantive content flow.

Word/LibreOffice may ignore keep-with-next and page-break properties inside a
large outer table. Verify the rendered effect. Where needed, adjust paragraph
grouping or table structure within the same field; do not assume a property fixed
the result. Rerender and inspect after every layout change. Visual review is
mandatory; the automated font check does not certify pagination.

## Calibration checks after future skill changes

1. Current version: March 31 => Q1; April 1 => Q2; December 31 => Q4;
   January 1 => Q1 of the new year. Exact output: YYYY Qn Version.
2. Language revision: 0.28 points per GB must not become 0.28 per user.
3. Capability: “may be reused only if...” must not become unconditional reuse.
4. Roles: swapping Supplier and Customer RASCI values must require review.
5. Formatting-only: preserve service facts and authorised blanks while applying
   current version and typography rules.
6. Sparse/conflicting input: ask one consolidated set of material questions;
   never fill unknown facts from an analogous catalogue service.
7. An authorised open question remains open in the draft. Human review is always
   required, even if all automatic checks pass.
