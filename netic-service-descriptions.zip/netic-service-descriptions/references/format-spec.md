# Native Word template specification

## Authority

Use assets/netic-service-template.docx directly. It is the exact user-supplied
Template - NEW Business Service Description.docx, received 28 October 2026.
Clone it and replace content in its existing cells. Do not clear the document
body, reconstruct its tables, replace its styles or apply old PDF geometry.

The retained 2026 Q4 PDF is a historical factual/vocabulary reference. Its Barlow
font, 16 pt title, shaded definitions chip and nine-row layout do not govern output.

## Fixed outer structure

Retain these eleven rows in this order, using the native labels:

1. Service Name
2. Service ID
3. Service Version
4. Service Accountable (Owner)/(Commercial  responsible)
5. Service Offerings
6. Bundling and tiering
7. Normal Operating Time
8. Service Level Agreements
9. Responsibilities
10. Related Technical Services
11. Price Model (based on the cost drivers of the corresponding Technical Services and Configuration Items)

Do not substitute the old optional Related Services row. For a formatting-only
migration, newly introduced administrative rows remain blank when the source
has no value. Disclose these blanks without inventing facts.

## Exact formatting

Native XML is authoritative except for the explicit user correction of 28 October 2026: all table text and typing sizes must be 10 pt, including Service Offerings and nested tables. The source template remains untouched. The title and definitions line retain their separate sizes. These measurements explain the layout, not a rebuilding recipe.

| Element | Template formatting |
| --- | --- |
| Page | Portrait A4, 11909 × 16834 twips |
| Margins | Top 992.125984 twips; bottom/left/right 1440 twips |
| Title | Arial 26 pt, native Title style, 1.5 line spacing; replace with service name |
| Definitions | Arial 11 pt; actual blue underlined hyperlink and original target |
| Outer table | Fixed 9000 twips; columns 2445 / 6555 twips |
| Outer borders | Black 1 pt |
| Outer cell padding | 100 twips each side; top alignment |
| Labels | Roboto 10 pt, single spacing |
| Identity, owner, tiers, hours, SLA | Roboto 10 pt, 1.5 spacing |
| Service Offerings | Arial 10 pt (user correction), justified, line spacing 280/240 |
| RASCI introduction | Roboto 10 pt, 1.5 spacing |
| RASCI header | Roboto 10 pt, single spacing, native light-grey fill |
| RASCI body | Native Arial 10 pt inheritance, single spacing; centred role columns |
| Pricing | Roboto 10 pt; bold headings with 1.5 spacing, alternatives single-spaced |
| Headers/footers | None |

Preserve styles, cell properties, grids, relationships and paragraph/run properties.
Empty paragraphs carry their typing format in pPr/rPr; transfer it to inserted
runs. Clone native row prototypes when extending RASCI. Never copy sample roles.
Content can flow across pages; keep short nested rows intact. Do not reduce font
size. All paragraphs and tables must remain editable. Price details stay inside
Price Model. Inspect every rendered page.

## SLA and pricing

Keep all four native SLA labels: Availability (of the service within the normal
operating time) SLA; Response time SLA; Resolution time SLA; Other SLA.

Template values (99%, n/a), RASCI roles and preselected fees are samples only.
Replace them with sourced values or authorised blanks.

Retain the four implementation and six recurring alternatives in native order.
Mark confirmed selections with x, or (x) with a confirmed condition. Replace
unselected “which ones” instructions with “specified Managed Services”; selected
inclusion options require actual names. Do not use the historical Contain
Operating fee variant in this native template.
