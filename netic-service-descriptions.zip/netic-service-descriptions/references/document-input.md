# Builder input and verification

## Invocation

Use CODEX_PRIMARY_RUNTIME_PYTHON with scripts/build_service_docx.py:

- New/revised facts: --data service.json --output result.docx
- Formatting only: --restyle existing.docx --output result.docx

Use the active Documents skill's required create/edit marker before authoring.

The canonical asset is the untouched user-provided native DOCX. Never regenerate
or overwrite it. The builder populates its existing cells, preserves its styles
and hyperlink, and clones its native RASCI and fee rows.

## JSON contract

Required fields:

- operation: new, revise or reproduce
- unresolved_questions: [] (questions expressly approved for display are content,
  not blockers in this array)
- catalogue_number: a confirmed value such as 10.14, or null with explicit omission
- service_name, service_id, service_version, service_owner: strings
- offerings, bundling: nonempty arrays of text or content blocks
- operating_time: string
- sla: availability, response, resolution, other strings
- supplier_label: The Supplier or Netic
- responsibilities: rows with task, supplier, customer strings
- related_technical_services: string, always rendered in the native row
- pricing_variant: standard
- implementation_fee: four rows with mark and text
- recurring_fee: six rows with mark and text
- evidence: source-map object
- authorised_placeholders: exact JSON paths for authorised blank/placeholder fields

Optional price_details is a list of paragraphs or heading blocks inside Price Model.
Optional implementation_fee_note and recurring_fee_note each require evidence.

Empty service_id, service_version, service_owner, operating_time or
related_technical_services require their exact path in authorised_placeholders.
A blank RASCI role is an explicit empty string and must be supported by that
responsibility row's evidence. Do not use a fake value to bypass validation.

Each content block may be:
- A plain paragraph string.
- type p/heading/bullet and text; optional space_before/space_after, 0–24 pt.
- bullet supports level 1–3.
- type table, headers, rows, optional widths; currently three columns are supported.
- type image, absolute supplied-image path, optional sourced caption.

Do not silently drop unsupported source images, links or tables. Migrate these
explicitly with a source map; the restyle route stops rather than flattening them.
Preserve native spacing, alignment and font families per field, but apply the user override: all table text and paragraph typing sizes are 10 pt.
New headings inside a field can be bold while retaining that field's font/size.

## Pricing alternatives

Retain four implementation rows in order:
1. n/a
2. Included in all implementation fees of any Managed Services delivered by Netic
3. Included in the implementation fees of specified Managed Services
4. Contract dependent: T&M, fixed price per service, fixed price implementation

Retain six recurring rows:
1. n/a
2. Included in all recurring fees of any Managed Services delivered by Netic
3. Included in the recurring fees of specified Managed Services
4. Consumption-based recurring fee, i.e. variable fee
5. Subscription-based recurring fee, i.e. fixed monthly fee
6. T&M

Marks are empty, x or (x). Selections require complete evidence, including any
mixed/conditional model. Unselected rows do not mean unknown. Selected inclusion
rows must name actual services. Do not inherit template checkmarks.

## Evidence coverage

Each evidence entry has nonempty source and support, with a concrete locator and
supporting passage or user statement. Include these paths:

- service_name, service_id, service_version, catalogue_number, service_owner,
  operating_time, related_technical_services
- sla.availability, sla.response, sla.resolution, sla.other
- offerings.0 ...; bundling.0 ...; responsibilities.0 ...; price_details.0 ...
- implementation_fee, recurring_fee
- implementation_fee_note, recurring_fee_note when used

Composite blocks require evidence for all claims. The validator checks coverage,
not factual truth; independently audit meaning and authorised exceptions.
New service IDs and catalogue numbers must not collide with the historical index.

## Formatting-only migration

--restyle preserves service wording, values, fee selections, approved questions
and blank roles. It adds absent owner and technical-service rows as blanks,
disclosed at delivery. It does not fill or approve missing facts.

Compare extracted values before/after. Rich content beyond the safe migration
capability requires explicit transfer, not silent loss. Do not restart intake for
facts already settled in the source description.

## QA and fonts

Run scripts/check_typography.py result.docx and require a pass before delivery. Use --fix to normalise an existing document, preserving fonts and emphasis. The builder checks automatically after saving. Sanitise the title, then render every page with the Documents renderer. Set
XDG_DATA_HOME to the real font directory so its temporary HOME can find Roboto.
Never repurpose HOME. Inspect every page at readable resolution and check PDF
font names when a fallback is suspected.

The bundled Roboto has Latin coverage. For additional scripts, obtain a suitable
licensed font without silently changing the specified DOCX typeface. Arial can
use a metrically compatible rendering fallback; retain Arial in the document.
Word and Google Docs may paginate differently.

Return the final DOCX, not internal JSON, source maps or QA images, unless asked.
Save/revise the file according to Library instructions.

Standing user defaults: every output is a qualified draft requiring human review. Service Version is automatically YYYY Qn Version for the current Europe/Copenhagen quarter/year; no question or separate approval is required. This overrides earlier requirements to confirm the version and to preserve it verbatim during format-only migration.
