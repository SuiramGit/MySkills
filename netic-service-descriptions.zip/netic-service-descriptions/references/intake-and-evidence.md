# Intake and evidence decisions

## Conversation

Start from what is known: “Jeg kan se, at servicen omfatter X og Y. Jeg mangler …”. Ask in Danish and use the supplied technical terms. Do not ask a generic opening question when the task is clear, or ask for already-attached files.

Prioritise up to three groups per round, asking only unanswered items necessary for this description:

1. **Identity and scope:** name; catalogue number/placement or explicit omission; confirmed Service ID, version and service owner; related technical services; deliveries, boundaries, customer prerequisites, included/excluded features and links to other services.
2. **Delivery commitments:** bundling; whether tiers exist and their differences; Normal Operating Time; all four SLA categories; RPO/RTO/retention when mentioned. Monitoring does not imply incident response.
3. **Responsibility and commercial model:** Netic/customer allocation for the actual tasks; implementation and recurring fee choices; billing units and conditions. Ask for the model, not actual prices, unless needed.

For a vague idea, start with scope and purpose, then ask remaining questions in subsequent turns. For detailed inputs, extract first and ask only about holes/conflicts.

Make conflicts concrete: “På side 35 står der højst én backup om dagen, mens side 36 angiver RPO på én time for produktionsdatabaser. Hvilken regel gælder for den nye service?” Do not choose a number or declare the source wrong.

## Evidence discipline

- Source statements apply to the service they describe. A catalogue entry can establish a related service's name/ID, but not that it is included, billed, required, or technically inherited by the new service.
- “Samme SLA som BS.CON.CACHE” can establish the exact referenced values after reading that record. Clarify ambiguous references such as “ligesom caching”.
- Explicit corrections supersede the specific earlier statement; recency or source polish alone does not resolve conflicts.
- Unknown is not n/a. “Ingen SLA” may require confirming whether all four categories are n/a.
- Negative claims need evidence too: “backup is not included” cannot be assumed.
- Improve grammar without changing meaning; preserve may/can/will, optional/mandatory, manual/automatic, units, qualifiers, and technical terms.
- Never expand “supports encryption” to “all data is encrypted”, monitoring to incident handling, platform to application management, or an add-on to an included feature.
- RASCI roles R/A/S/C/I must be sourced/confirmed. A blank role is unknown until confirmed blank. Flag inconsistent or multiple accountable parties; do not silently repair.
- Source anomalies include Gold/Silver amidst Basic/Standard/Premium in Backup Services, two Managed Database Services, and references to services without standalone entries. Do not propagate or normalise by assumption.

## Generation gate

Create only after mandatory fields are evidenced or the user explicitly authorises particular omissions/placeholders; consequential scope must be clear and material conflicts resolved. Do not introduce unnecessary detail just to fill space.

If asked to propose service design, keep proposals clearly labelled in conversation and wait for decisions before asserting them in the document. If a placeholder is explicitly authorised, keep it visible in the corresponding field and disclose incompleteness in the handoff.

For an authorised format-only migration, follow SKILL.md: retain existing unknowns, leave newly introduced administrative rows blank, and disclose them. Do not restart factual intake or import template sample values.

Standing user defaults: every output is a qualified draft requiring human review. Service Version is automatically YYYY Qn Version for the current Europe/Copenhagen quarter/year; no question or separate approval is required. This overrides earlier requirements to confirm the version and to preserve it verbatim during format-only migration.
