# Catalogue index

Source: retained 219-page PDF; SHA-256 b82b97aa09b56371052ad24ee0b4b7d94cd96039b409504b49198ce36bf09de4.
All facts below describe the 2026 Q4 reference catalogue, not current or new-service commitments.

| No. | Service | Service ID | PDF pages | Text |
|---|---|---|---|---|
| 1.1 | ITSM Services - Asset Management | BS.FND.ASSET | 6-8 | [BS.FND.ASSET](services/bs-fnd-asset.txt) |
| 1.2 | ITSM Services - Change Management | BS.FND.CM | 9-14 | [BS.FND.CM](services/bs-fnd-cm.txt) |
| 1.3 | ITSM Services - Event and Incident Management | BS.FND.IM | 15-18 | [BS.FND.IM](services/bs-fnd-im.txt) |
| 1.4 | ITSM Services - Managed IT Service Management Platform | BS.FND.ITSM | 19-21 | [BS.FND.ITSM](services/bs-fnd-itsm.txt) |
| 1.5 | ITSM Services - Problem Management | BS.FND.PM | 22-24 | [BS.FND.PM](services/bs-fnd-pm.txt) |
| 1.6 | ITSM Services - Service Request Management | BS.FND.SRQM | 25-27 | [BS.FND.SRQM](services/bs-fnd-srqm.txt) |
| 1.7 | Monitoring & Alerting Services | BS.FND.MON | 28-30 | [BS.FND.MON](services/bs-fnd-mon.txt) |
| 1.8 | Service Desks Services | BS.FND.SD | 31-33 | [BS.FND.SD](services/bs-fnd-sd.txt) |
| 2.1 | Backup Services | BS.SCM.BKUP | 34-37 | [BS.SCM.BKUP](services/bs-scm-bkup.txt) |
| 2.2 | Capacity Management | BS.SCM.CAPA | 38-40 | [BS.SCM.CAPA](services/bs-scm-capa.txt) |
| 2.3 | Configuration Management | BS.SCM.CONFIG | 41-43 | [BS.SCM.CONFIG](services/bs-scm-config.txt) |
| 2.4 | Disaster Recovery Services | BS.SCM.DR | 44-46 | [BS.SCM.DR](services/bs-scm-dr.txt) |
| 2.5 | Managed Event Logging Services | BS.SCM.ELOG | 47-49 | [BS.SCM.ELOG](services/bs-scm-elog.txt) |
| 2.6 | Patch Management | BS.SCM.PATCH | 50-53 | [BS.SCM.PATCH](services/bs-scm-patch.txt) |
| 2.7 | Restore Services | BS.SCM.RESTOR | 54-56 | [BS.SCM.RESTOR](services/bs-scm-restor.txt) |
| 3.1 | Consulting Services | BS.PRO.CONSULT | 57-59 | [BS.PRO.CONSULT](services/bs-pro-consult.txt) |
| 3.2 | Customer Governance | BS.PRO.GOV | 60-62 | [BS.PRO.GOV](services/bs-pro-gov.txt) |
| 3.3 | Project Management | BS.PRO.PROJ | 63-65 | [BS.PRO.PROJ](services/bs-pro-proj.txt) |
| 3.4 | Reporting Services | BS.PRO.REP | 66-68 | [BS.PRO.REP](services/bs-pro-rep.txt) |
| 4.1 | Certificate Management Services | BS.SEC.CERTIF | 69-71 | [BS.SEC.CERTIF](services/bs-sec-certif.txt) |
| 4.2 | Compliance Logging Services | BS.SEC.ALOG | 72-74 | [BS.SEC.ALOG](services/bs-sec-alog.txt) |
| 4.3 | Core Compliance Services | BS.SEC.CORECOMP | 75-77 | [BS.SEC.CORECOMP](services/bs-sec-corecomp.txt) |
| 4.4 | Core Security Services | BS.SEC.CORE | 78-81 | [BS.SEC.CORE](services/bs-sec-core.txt) |
| 4.5 | External Auditing Services | BS.SEC.EXTAUDIT | 82-84 | [BS.SEC.EXTAUDIT](services/bs-sec-extaudit.txt) |
| 4.6 | Identity and Access Management | BS.SEC.IAM | 85-88 | [BS.SEC.IAM](services/bs-sec-iam.txt) |
| 4.7 | License Management | BS.SEC.LIC | 89-91 | [BS.SEC.LIC](services/bs-sec-lic.txt) |
| 4.8 | Quarterly Security Review | BS.SEC.SECREVIEW | 92-94 | [BS.SEC.SECREVIEW](services/bs-sec-secreview.txt) |
| 4.9 | RISK Management | BS.SEC.RISK | 95-97 | [BS.SEC.RISK](services/bs-sec-risk.txt) |
| 4.10 | Security Clearance Management | BS.SEC.CLEARANCE | 98-100 | [BS.SEC.CLEARANCE](services/bs-sec-clearance.txt) |
| 4.11 | Vulnerability Management | BS.SEC.VUM | 101-103 | [BS.SEC.VUM](services/bs-sec-vum.txt) |
| 5.1 | Core Datacenter Services | BS.HSG.CORE | 104-106 | [BS.HSG.CORE](services/bs-hsg-core.txt) |
| 5.2 | Managed Colocation Services | BS.HSG.COLOC | 107-109 | [BS.HSG.COLOC](services/bs-hsg-coloc.txt) |
| 6.1 | Core Network Services | BS.NWS.CORE | 110-112 | [BS.NWS.CORE](services/bs-nws-core.txt) |
| 6.2 | Managed Connections Services | BS.NWS.CONNECT | 113-115 | [BS.NWS.CONNECT](services/bs-nws-connect.txt) |
| 6.3 | Managed DDoS Protection Services | BS.NWS.DDOS | 116-118 | [BS.NWS.DDOS](services/bs-nws-ddos.txt) |
| 6.4 | Managed Firewall Services | BS.NWS.FW | 119-121 | [BS.NWS.FW](services/bs-nws-fw.txt) |
| 6.5 | Managed Internet Connections Services | BS.NWS.INET | 122-124 | [BS.NWS.INET](services/bs-nws-inet.txt) |
| 6.6 | Managed Load-Balancing Services | BS.NWS.LB | 125-127 | [BS.NWS.LB](services/bs-nws-lb.txt) |
| 6.7 | Managed Switching Network Services | BS.NWS.SW | 128-130 | [BS.NWS.SW](services/bs-nws-sw.txt) |
| 7.1 | Managed Block Storage Service | BS.STO.SAN | 131-133 | [BS.STO.SAN](services/bs-sto-san.txt) |
| 7.2 | Managed Object Storage Service | BS.STO.OBJECT | 134-137 | [BS.STO.OBJECT](services/bs-sto-object.txt) |
| 8.1 | Infrastructure-Managed Virtual Machines | BS.CMP.IMVM | 138-141 | [BS.CMP.IMVM](services/bs-cmp-imvm.txt) |
| 8.2 | Managed Bare Metal Server | BS.CMP.BAREMETAL | 142-145 | [BS.CMP.BAREMETAL](services/bs-cmp-baremetal.txt) |
| 8.3 | Managed Hypervisor Host | BS.CMP.HYPERV | 146-148 | [BS.CMP.HYPERV](services/bs-cmp-hyperv.txt) |
| 8.4 | OS-Managed Virtual or Physical Machines | BS.CMP.OS | 149-151 | [BS.CMP.OS](services/bs-cmp-os.txt) |
| 9.1 | Managed Database Service | BS.DB.OPS | 152-155 | [BS.DB.OPS](services/bs-db-ops.txt) |
| 10.1 | Contain Application Management | BS.CON.AM | 156-158 | [BS.CON.AM](services/bs-con-am.txt) |
| 10.2 | Contain Application Operation | BS.CON.AO | 159-161 | [BS.CON.AO](services/bs-con-ao.txt) |
| 10.3 | Contain Core Platform | BS.CON.CCP | 162-170 | [BS.CON.CCP](services/bs-con-ccp.txt) |
| 10.4 | Contain Managed Application Platform | BS.CON.PLATF | 171-179 | [BS.CON.PLATF](services/bs-con-platf.txt) |
| 10.5 | Managed Application Observability Service | BS.CON.OBSERV | 180-183 | [BS.CON.OBSERV](services/bs-con-observ.txt) |
| 10.6 | Managed Caching Service | BS.CON.CACHE | 184-187 | [BS.CON.CACHE](services/bs-con-cache.txt) |
| 10.7 | Managed Container Registry Service | BS.CON.CONREG | 188-190 | [BS.CON.CONREG](services/bs-con-conreg.txt) |
| 10.8 | Managed Database Service | BS.CON.DB | 191-194 | [BS.CON.DB](services/bs-con-db.txt) |
| 10.9 | Managed GIT Repository Service | BS.CON.GIT | 195-197 | [BS.CON.GIT](services/bs-con-git.txt) |
| 10.10 | Managed Messaging Service | BS.CON.MESG | 198-200 | [BS.CON.MESG](services/bs-con-mesg.txt) |
| 10.11 | Managed Search Service | BS.CON.SEARCH | 201-203 | [BS.CON.SEARCH](services/bs-con-search.txt) |
| 10.12 | Managed Service Mesh Service | BS.CON.MESH | 204-206 | [BS.CON.MESH](services/bs-con-mesh.txt) |
| 10.13 | Managed Streaming Service | BS.CON.STREAM | 207-209 | [BS.CON.STREAM](services/bs-con-stream.txt) |
| 11.1 | Development Services | BS.APP.DEV | 210-213 | [BS.APP.DEV](services/bs-app-dev.txt) |
| 11.2 | Managed 3rd party Application Service | BS.APP.3RDPARTY | 214-216 | [BS.APP.3RDPARTY](services/bs-app-3rdparty.txt) |
| 11.3 | Managed Custom Application Service | BS.APP.CUSTOM | 217-219 | [BS.APP.CUSTOM](services/bs-app-custom.txt) |
